<?php
class formation{
    public $pat1;
    public $lieu1;
    public $p1;
    public $work1;
    public $pat2;
    public $lieu2;
    public $p2;
    public $work2;
    public $pat3;
    public $lieu3;
    public $p3;
    public $work3;

function __construct($pat1,$lieu1,$p1,$work1,$pat2,$lieu2,$p2,$work2,$pat3,$lieu3,$p3,$work3){
    $this->pat1=$pat1;
    $this->lieu1=$lieu1;
    $this->p1=$p1;
    $this->work1=$work1;
    $this->pat2=$pat2;
    $this->lieu2=$lieu2;
    $this->p2=$p2;
    $this->work2=$work2;
    $this->pat3=$pat3;
    $this->lieu3=$lieu3;
    $this->p3=$p3;
    $this->work3=$work3;
}
function get_pat1(){
    return $this->pat1;
}
function get_lieu1(){
    return $this->lieu1;
}
function get_p1(){
    return $this->p1;
}
function get_work1(){
    return $this->work1;
}
function get_pat2(){
    return $this->pat2;
}
function get_lieu2(){
    return $this->lieu2;
}
function get_p2(){
    return $this->p2;
}
function get_work2(){
    return $this->work2;
}
function get_pat3(){
    return $this->pat3;
}
function get_lieu3(){
    return $this->lieu3;
}
function get_p3(){
    return $this->p3;
}
function get_work3(){
    return $this->work3;
}   
}
$formation = new formation ("Formation","- Genius Center","Juin 2019 - Aout 2019","Réalisation, montage d un robot Arduino","Stage Academique","- Solidarité Technologique","Juin 2020 -Septembre 2020","Recyclage des appareils élctronique","Stage Academique","- Necta Global Consulting","Juin 2021 - Aout 2021 http://nectags.com","Réalisation de site web de présentation");
?>



<div id="pat2">
                    <div id="inl">
                        <p id="p3"><?php echo $formation->get_pat1();?><strong> <?php echo $formation->get_lieu1();?></strong></p>
                        <p id="p4"><?php echo $formation->get_p1();?></p>
                        <p id="p5"> <?php echo $formation->get_work1();?></p>
                        <hr id="lign1">
                    </div>
                    <p id="p3"><?php echo $formation->get_pat2();?> <strong>  <?php echo $formation->get_lieu2();?></strong></p>
                    <p id="p4"><?php echo $formation->get_p2();?> </p>
                    <p id="p5"> <?php echo $formation->get_work2();?></p>
                    <hr id="lign1">
                    <div id="inl">
                        <p id="p3"><?php echo $formation->get_pat3();?><strong> <?php echo $formation->get_lieu3();?></strong></p>
                        <p id="p4"><?php echo $formation->get_p3();?></p>
                        <p id="p5"> <?php echo $formation->get_work3();?> </p>
                        <hr id="lign1">
                    </div>
  </div>