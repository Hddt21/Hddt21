


<?php 
//informations personnelles
class info{
    public $nom ;
    public $metier ;
    function __construct($nom, $metier)
    {
        $this->nom= $nom;
        $this->metier = $metier;
    }
    function get_nom()
    {
        return $this->nom;
    }     
    function get_metier()
    {
    return $this->metier;    
    }
}
 $info = new info("Henke DIBABO Darryl","Devellopeur Web/Admin BD");
 

 // classes descriptions
class descriptions{
    public $naiss;
    public $origine;
    public $situe;

    function __construct($naiss, $origine, $situe){
        $this->naiss= $naiss;
        $this->origine=$origine;
        $this->situe=$situe;
    }   
    function get_naiss(){
        return $this->naiss;
    }
    function get_origine(){
        return $this->origine;
    }
    function get_situe(){
        return $this->situe;
     }
}
$descriptions = new descriptions("13 Aout 2000","Originaire de Ouest cameroun","Célibataire");

   //situation géographique 
 class géograph{
     public $local;
     public $ville;
     public $map;

  function __construct($local, $ville, $map){
      $this->local=$local;
      $this->ville=$ville;
      $this->map=$map;
  }
  function get_local(){
      return $this->local;
  }
  function get_ville(){
      return $this->ville;
  }
  function get_map(){
      return $this->map;
  }
 }   
 $géograph = new géograph("Yassa entrée-Kaza"," Douala"," Map :4.053276? 9.765047 ");
 
//coordonnées
class coordoné{
    public $phone;
    public $courrier;
    public $mail;
    public $plate;
    public $projet1;
    public $projet2;
 
function __construct($phone, $courrier, $mail, $plate,$projet1,$projet2 ){
    $this->phone=$phone;
    $this->courrier=$courrier;
    $this->mail=$mail;
    $this->plate=$plate;
    $this->projet1=$projet1;
    $this->projet2=$projet2;
}
function get_phone(){
    return $this->phone;
}
function get_courrier(){
    return $this->courrier;
}
function get_mail(){
    return $this->mail;
}
function get_plate(){
    return $this->plate;
}
function get_projet1(){
    return $this->projet1;
}
function get_projet2(){
    return $this->projet2;
}
}  
$coordoné = new coordoné("(+237) 694 715 623","Telegram, Whatsapp","darryldibabo18@gmail.com","Google+,Github","+3 PROJETS  ","+31 CONTACTS ");     
                   
// compétences
class compétences{
    public $desc1;
    public $comp1;
    public $desc2;
    public $comp2;
    public $desc3;
    public $comp3;
    public $desc4;
    public $comp4;
    public $desc5;
    public $comp5;
    public $desc6;
    public $comp6;

    function __construct($desc1, $comp1, $desc2, $comp2,$desc3,$comp3,$desc4,$comp4,$desc5,$comp5,$desc6,$comp6 ){
        $this->desc1=$desc1;
        $this->comp1=$comp1;
        $this->desc2=$desc2;
        $this->comp2=$comp2;
        $this->desc3=$desc3;
        $this->comp3=$comp3;
        $this->desc4=$desc4;
        $this->comp4=$comp4;
        $this->desc5=$desc5;
        $this->comp5=$comp5;
        $this->desc6=$desc6;
        $this->comp6=$comp6;
    }
    function get_desc1(){
        return $this->desc1;
    }
    function get_comp1(){
        return $this->comp1;
    }
    function get_desc2(){
        return $this->desc2;
    }
    function get_comp2(){
        return $this->comp2;
    }
    function get_desc3(){
        return $this->desc3;
    }
    function get_comp3(){
        return $this->comp3;
    }
    function get_desc4(){
        return $this->desc4;
    }
    function get_comp4(){
        return $this->comp4;
    }
    function get_desc5(){
        return $this->desc4;
    }
    function get_comp5(){
        return $this->comp4;
    }
    function get_desc6(){
        return $this->desc4;
    }
    function get_comp6(){
        return $this->comp6;
    }
}
$compétences = new compétences("Développement Front-End","HTML5, JavaFX, ...","Développement Java","Eclipse","Bases de données","MySql,Oracle 11g","UX Design","Photoshop","Outils d environnement","Visual Code, Git","Programmation","Arduino"); 
?>
<div class="cv_profile">
                <!--Description, Adress -->
                <p id="text2"><strong><?php echo $info->get_nom();?></strong></p>
                <p id="metier"><sub><?php echo $info->get_metier();?></sub></p>
                <img id="img4" src="img/ajouter.png" alt="ajouter">
                <img id="img4" src="img/pngtree-file-downloa.jpg" alt="ajouter">
                <a href="codesent.php">
                     <img id="img4" src="img/gmail-logo.jpg" alt="mail_to">
                </a>
                <img id="img4" src="img/WhatsAppg.png" alt="whats_me">
                <img id="img4" src="img/telegram.jpg" alt="telegram_me">


                <p id="img5"><img src="img/cake.png" style="width: 35px; height:35px" alt="gateau"></p>
                <p id="text3"><?php echo $descriptions->get_naiss();?><br><?php echo $descriptions->get_origine();?><br><?php echo $descriptions->get_situe();?></p>
                <hr id="ligne">
                <p id="img6"><img src="img/loc.png" style="width: 35px; height:35px" alt="Localisation"></p>
                <p id="text4"><?php echo $géograph->get_local()?><br><?php echo $géograph->get_ville()?> <br><?php echo $géograph->get_map()?></p>
                <hr id="ligne1">
                <p id="img7"><img src="img/tel.png" style="width: 35px; height:35px" alt="Localisation"></p>
                <p id="text6"><?php echo $coordoné->get_phone();?><br><?php echo $coordoné->get_courrier();?></p>
                <hr id="ligne2">
                <p id="img8"><img src="img/email.png" style="width: 35px; height:35px" alt="Localisation"></p>
                <p id="text7"><?php echo $coordoné->get_mail();?><br><?php echo $coordoné->get_plate();?></p>
                <br>
                <p id="text8">
                    <tia style="color:rgba(255, 255, 255, 0.856);"><?php echo $coordoné->get_projet1();?></tia> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $coordoné->get_projet2();?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    3 ANS D'EXP 
                </p>
                <!--End Description, Adress -->
                <hr id="caract3">
                <div id="desc">
                    <div id="text9">
                        <p id="case"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $compétences->get_desc1();?></strong></p>
                        <p id="etoile"><span>*</span></p>
                    </div>
                    <p id="id1"><sub><?php echo $compétences->get_comp1();?></sub></p>
                    <p id="level1"><input style="width: 283px;" type="range" max=100 value=85></p>
                    <div>
                        <div id="text10">
                            <p id="case1"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $compétences->get_desc2();?></strong></p>
                            <p id="etoile1"><span>*</span></p>
                        </div>
                        <p id="id1"><sub><?php echo $compétences->get_comp2();?></sub></p>
                        <p id="level1"><input style="width: 283px;" type="range" max=100 value=65></p>
                    </div>
                    <div>
                        <div id="text10">
                            <p id="case1"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $compétences->get_desc3();?></strong></p>
                            <p id="etoile1"><span>*</span></p>
                        </div>
                        <p id="id1"><sub><?php echo $compétences->get_comp3();?><</sub></p>
                        <p id="level1"><input style="width: 283px;" type="range" max=100 value=58></p>
                    </div>
                    <div>
                        <div id="text10">
                            <p id="case1"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $compétences->get_desc4();?></strong></p>
                            <p id="etoile1"><span>*</span></p>
                        </div>
                        <p id="id1"><sub><?php echo $compétences->get_comp4();?></sub></p>
                        <p id="level1"><input style="width: 283px;" type="range" max=100 value=70></p>
                    </div>
                    <div>
                        <div id="text10">
                            <p id="case1"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $compétences->get_desc5();?></strong></p>
                            <p id="etoile1"><span>*</span></p>
                        </div>
                        <p id="id1"><sub><?php echo $compétences->get_comp5();?></sub></p>
                        <p id="level1"><input style="width: 283px;" type="range" max=100 value=74></p>
                    </div>
                    <div>
                        <div id="text10">
                            <p id="case1"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $compétences->get_desc6();?></strong></p>
                            <p id="etoile1"><span>*</span></p>
                        </div>
                        <p id="id1"><sub><?php echo $compétences->get_comp6();?></sub></p>
                        <p id="level1"><input style="width: 283px;" type="range" max=100 value=45></p>
                    </div>

                </div>

            </div>
