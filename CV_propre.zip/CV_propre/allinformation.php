<?php
require "cv_profile.php";
$géograph = new géograph("Yassa entrée-Kaza"," Douala"," Map :4.053276? 9.765047 ");

?>