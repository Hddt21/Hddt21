<?php
class Interets{
    public $int1;
    public $title;
    public $lang;
    public $pratic;
    public $l1;
    public $l2;

function __construct($int1,$title,$lang,$pratic,$l1,$l2)
{
    $this->int1=$int1;
    $this->title=$title;
    $this->lang=$lang;
    $this->pratic=$pratic;
    $this->l1=$l1;
    $this->l2=$l2;
}
function get_int1(){
    return $this->int1;
}
function get_title(){
    return $this->title;
}
function get_lang(){
    return $this->lang;
}
function get_pratic(){
    return $this->pratic;
}
function get_l1(){
    return $this->l1;
}
function get_l2(){
    return $this->l2;
}
}
$Interets = new Interets("Point d interets","Simple passe temps pour se faire plaisir","Langues","pratiquées en entreprise","Français","Anglais");
?>


<div id="interet">
                        <div>
                            <!--Interets -->
                            <h3 id="text11"><?php echo $Interets->get_int1();?></h3>
                            <p id="p16"><?php echo $Interets->get_title();?></p>
                            <img id="img9" src="img/need.png" alt="">

                        </div>
                    </div>

                    <div class="langues">
                        <div>
                            <h3 id="text11"> <?php echo $Interets->get_lang();?></h3>
                            <i id="p6"><?php echo $Interets->get_pratic();?></i>
                        </div>

                        <div class="lang">
                            <img id="img11" src="img/box.png">
                            <p id="text12"><?php echo $Interets->get_l1();?></p>
                        </div>

                        <div class="lang">
                            <img id="img12" src="img/box.png">
                            <p id="text12"><?php echo $Interets->get_l2();?></p>
                        </div>
                    </div>