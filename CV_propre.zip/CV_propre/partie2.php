<?php
// Cursus académique
class cursus{
    public $curs;
    public $clas1;
    public $ecole1;
    public $annee1;
    public $proj1;
    public $class2;
    public $ecole2;
    public $annee2;
    public $proj2;
    public $class3;
    public $ecole3;
    public $annee3;
    public $class4;
    public $ecole4;
    public $annee4;
function __construct($curs,$clas1,$ecole1,$annee1,$proj1,$class2,$ecole2,$annee2,$proj2,$class3,$ecole3,$annee3,$class4,$ecole4,$annee4)
{
    $this->curs=$curs;
    $this->clas1=$clas1;
    $this->ecole1=$ecole1;
    $this->annee1=$annee1;
    $this->proj1=$proj1;
    $this->class2=$class2;
    $this->ecole2=$ecole2;
    $this->annee2=$annee2;
    $this->proj2=$proj2;
    $this->class3=$class3; 
    $this->proj3=$ecole3;
    $this->annee3=$annee3;
    $this->class4=$class4;
    $this->ecole4=$ecole4;
    $this->annee4=$annee4;
}
function get_curs(){
    return $this->curs;
}
function get_clas1(){
    return $this->clas1;
}
function get_ecole1(){
    return $this->ecole1;
}
function get_annee1(){
    return $this->annee1;
}
function get_proj1(){
    return $this->proj1;
}
function get_class2(){
    return $this->class2;
}
function get_ecole2(){
    return $this->ecole2;
}
function get_annee2(){
return $this->annee2;
}
function get_proj2(){
    return $this->proj2;
}
function get_class3(){
    return $this->class3;
}
function get_ecole3(){
    return $this->ecole3;
}
function get_annee3(){
    return $this->annee3;
}

function get_class4(){
    return $this->class4;
}
function get_ecole4(){
    return $this->ecole4;
}
function get_annee4(){
    return $this->annee4;
}
}
$cursus = new cursus("Cursus académique","Classes préparatoires niveau 2 ","- IUC - Douala","2020/2021","Site Web de présentation de la société Necta Global Consulting","Classes préparatoires niveau 1 "
,"-IUC - Douala","2019/2020","Implementation du jeu de Shannon","Baccalaureat C" ,"- College Saint-Michel","2018/2019","PROBATOIRE C","- College Saint-Michel","2017/2018");
?>

<div id="partie2">
                        <div id="bas1"> <img src="img/bat.png" id="imag1" alt="expérience">
                            <p id="part3">
                            </p>
                            <!--Cursus academique -->
                            <p id="entre"><?php echo $curs['curs']?></p>
                            <p id="sous2"><em><sub></sub></em></p>
                        </div>
                        <p id="prt2"><img src="img/menu.png" id="imag2" alt="image"></p>
                        <div class="competency">
                            <div class="border">
                                <div id="pat3">
                                    <p id="p3"><?php echo $cursus->get_clas1();?> <strong><?php echo $cursus->get_ecole1();?></strong></p>
                                    <p id="p4"><?php echo $cursus->get_annee1();?></p>
                                    <p id="p5"> <?php echo $cursus->get_proj1();?></p>
                                    <hr id="lign1">
                                    <div id="inl">
                                        <p id="p3"><?php echo $cursus->get_class2();?><strong><?php echo $cursus->get_ecole2();?></strong></p>
                                        <p id="p4"><?php echo $cursus->get_annee2();?></p>
                                        <p id="p5"> <?php echo $cursus->get_proj2();?></p>
                                        <hr id="lign1">
                                    </div>
                                    <p id="p3"><?php echo $cursus->get_class3();?> <strong><?php echo $cursus->get_ecole3();?></strong></p>
                                    <p id="p4"><?php echo $cursus->get_annee3();?></p>
                                    <p id="p5"> </p>
                                    <hr id="lign1">
                                    <p id="p3"><?php echo $cursus->get_class4()?> <strong><?php echo $cursus->get_ecole4();?></strong></p>
                                    <p id="p4"><?php echo $cursus->get_annee4();?></p>
                                    <p id="p5"> </p>
                                    <hr id="lign1">
                                    <!--End Cursus academique -->
                                </div>
                            </div>
                        </div>
                    </div>